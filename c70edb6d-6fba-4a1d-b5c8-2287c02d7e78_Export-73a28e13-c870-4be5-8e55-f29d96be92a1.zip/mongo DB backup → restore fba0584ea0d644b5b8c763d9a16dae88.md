# mongo DB backup → restore

MONGO DB를 이관해야할 경우

local disk로 저장 후 신규 mongoDB로 복원

# Dump

```bash
HOST='' # DB host
PORT='' # DB port
USER_NAME='' # 있으면
USER_PWD='' # 있으면
DB_NAME='' # 저장하고자 하는 db_name
OUTPUT='' # 저장할 위치

mongodump --host=$HOST \
	        --port $PORT \
          -u $USER_NAME \
					-p $USER_PWD \
					--authenticationDatabase admin \
					--forceTableScan  
					--db $DB_NAME \
					--out $OUTPUT

```

![스크린샷 2023-06-20 오후 2.35.56.png](mongo%20DB%20backup%20%E2%86%92%20restore%20fba0584ea0d644b5b8c763d9a16dae88/%25E1%2584%2589%25E1%2585%25B3%25E1%2584%258F%25E1%2585%25B3%25E1%2584%2585%25E1%2585%25B5%25E1%2586%25AB%25E1%2584%2589%25E1%2585%25A3%25E1%2586%25BA_2023-06-20_%25E1%2584%258B%25E1%2585%25A9%25E1%2584%2592%25E1%2585%25AE_2.35.56.png)

# RESTORE

```bash
HOST='' # DB host
PORT='' # DB port
USER_NAME='' # 있으면
USER_PWD='' # 있으면
DB_NAME='' # 저장하고자 하는 db_name
OUTPUT='' # 저장할 위치

mongorestore --host=$HOST \
	        --port $PORT \
          -u $USER_NAME \
					-p $USER_PWD \
					--authenticationDatabase admin \
					--forceTableScan  
					--db $DB_NAME \
					--out $OUTPUT

mongorestore --host=idc.buzzni.com --port 32720 -u 'hsmoa-mongodb' -p 'buzzni2012!' ./27018
```